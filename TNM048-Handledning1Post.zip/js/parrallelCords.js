
function parrallelCords(rawData)
{
	var data = parseData(rawData);
    var transposed = transpose(data);

	//console.log(data);
	var div = d3.select(".parrallelDiv").append("div");
	
	var margin = {top: 40, right: 30, bottom: 10, left: 200};
	var width = 960 - margin.left - margin.right;
	var height = 500 - margin.top - margin.bottom;

	var line = d3.line(); 
	var foreground;
	var background;

	//Select the div and append our svg tag.
	var svg = div.append("svg")
		.attr("width", width + margin.left + margin.right)
		.attr("height", height + margin.top + margin.bottom)
		.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	var dimensions = [
		{
            name: "Name",
            scale: d3.scalePoint().domain(transposed[0].sort(d3.ascending)).range([height, 0]),
			type: "string"
		},
		{
			name: "Sales",
			scale: d3.scaleLinear().domain(d3.extent(transposed[1])).range([height, 0]).nice(),
			type: "number"
		},
		{
			name: "Score",
			scale: d3.scaleLinear().domain(d3.extent(transposed[2])).range([height, 0]).nice(),
			type: "number"
		},
		{
            name: "Genre",
            scale: d3.scalePoint().domain(transposed[3].sort(d3.ascending)).range([height, 0]),
			type: "string"
		}
	];

	var xScale = d3.scaleBand()
		.domain( d3.keys(rawData[0]))
		.range([0, width]);

	plot(data);

	function plot(results)
	{
		background = svg.append("g")
			.attr("class", "background")
			.selectAll("path")
			.data(data)
			.enter().append("path")
			.attr("d", path);

		foreground = svg.append("g")
			.attr("class", "foreground")
			.selectAll("path")
			.data(data)
			.enter().append("path")
            .attr("d", path)
            .style("stroke", "red");
			//.style("stroke", function (d, i) {  return colors[results.assignments[i]]; });

		// Add a group element for each dimension.
		var g = svg.selectAll(".dimension")
			.data(dimensions)
			.enter().append("g")
			.attr("class", "dimension")
			.attr("transform", function (d) { return "translate(" + xScale(d.name) + ")"; });

		// Add an axis and title.
		g.append("g")
			.attr("class", "axis")
			.each(function (d) { d3.select(this).call(d3.axisLeft(d.scale)); })
			.append("text")
			.attr("class", "title")
			.attr("text-anchor", "middle")
			.attr("y", -9)
			.style('fill', 'black')
			.text(function (d) { return d.name; });
	}

	// Returns the path for a given data point.
    
    function path(d) {
        var index = 0;
        console.log(d);

        return line(dimensions.map(function (p) { 
            
            var temp = [xScale(p.name), p.scale(d[index])];
            console.log(index);
            console.log(d[index]);
            ++index;
            return temp; 
		}));
	}
}

